import os
import zipfile
import shutil

os.makedirs('webtoapp_bundle/images', exist_ok=True)
shutil.copyfile('dist/index.html', 'webtoapp_bundle/index.html')
shutil.copyfile('dist/index.html', 'webtoapp_bundle/genealogy-app.html')
if os.path.exists('public/app_data.json'):
    shutil.copyfile('public/app_data.json', 'webtoapp_bundle/app_data.json')
if os.path.exists('public/manuscripts_data.json'):
    shutil.copyfile('public/manuscripts_data.json', 'webtoapp_bundle/manuscripts_data.json')
if os.path.exists('app-favicon.ico'):
    shutil.copyfile('app-favicon.ico', 'webtoapp_bundle/favicon.ico')

# Copy all 74 images into webtoapp_bundle/images/
if os.path.exists('public/images'):
    for img_file in os.listdir('public/images'):
        src_img = os.path.join('public/images', img_file)
        if os.path.isfile(src_img):
            shutil.copyfile(src_img, os.path.join('webtoapp_bundle/images', img_file))

readme_webtoapp = '''============================================================
دليل تشغيل التطبيق على WebToApp ونظام أندرويد (WebToApp Guide)
============================================================

1. محتويات هذه الحزمة:
   - index.html: تطبيق المشجر والموسوعة الشامل المدمج (Single-File Offline App).
     يحتوي على كافة الشيفرات (HTML + CSS + JS) وبيانات الأنساب والأكواد دون الحاجة لأي إنترنت.
   - app_data.json: قاعدة البيانات الكاملة لكافة الأسماء والأكواد والأجيال بصيغة JSON.
   - images/: مجلد صور المخطوطات والوثائق.

2. كيفية الاستخدام في WebToApp:
   أ) في موقع WebToApp.com:
      - اختر خيار 'Files / Local Files' (ملفات محلية) أو 'Zip Upload'.
      - ارفع ملف index.html أو ارفع هذا الملف المضغوط (ZIP) كاملاً.
      - اجعل الصفحة الرئيسية / مسار البدء (Start Page): index.html
      - فعّل خيارات:
        * Offline Mode / Local Cache (العمل بدون إنترنت)
        * File Access / Storage Permissions (للسماح بتحميل وحفظ التقارير)
   ب) في تطبيقات أندرويد WebView الأخرى (Android Studio / Capacitor / Cordova):
      - ضع محتويات هذه الحزمة في مجلد: app/src/main/assets/
      - اضبط عنوان WebView ليفتح: file:///android_asset/index.html
'''

with open('webtoapp_bundle/README_WebToApp.txt', 'w', encoding='utf-8') as f:
    f.write(readme_webtoapp)

with open('webtoapp_bundle/images/README.txt', 'w', encoding='utf-8') as f:
    f.write('مجلد مخصص لحفظ صور المخطوطات والوثائق الأصلية.')

# Create WebToApp ZIP
zip_webtoapp_path = 'public/Sharh-AlBahr-WebToApp-Ready.zip'
with zipfile.ZipFile(zip_webtoapp_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk('webtoapp_bundle'):
        for f in files:
            full_p = os.path.join(root, f)
            arc_p = os.path.relpath(full_p, 'webtoapp_bundle')
            z.write(full_p, arc_p)

# Also copy to root for convenience
shutil.copyfile(zip_webtoapp_path, 'Sharh-AlBahr-WebToApp-Ready.zip')
print('Created WebToApp zip:', zip_webtoapp_path, os.path.getsize(zip_webtoapp_path), 'bytes')

# Create Full Source Code ZIP
zip_source_path = 'public/Sharh-AlBahr-Complete-SourceCode.zip'
exclude_dirs = {'node_modules', '.git', 'dist', '.cache', 'webtoapp_bundle'}
with zipfile.ZipFile(zip_source_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
        for f in files:
            if f.endswith('.zip'):
                continue
            full_p = os.path.join(root, f)
            arc_p = os.path.normpath(full_p)
            z.write(full_p, arc_p)

shutil.copyfile(zip_source_path, 'Sharh-AlBahr-Complete-SourceCode.zip')
print('Created Source zip:', zip_source_path, os.path.getsize(zip_source_path), 'bytes')
